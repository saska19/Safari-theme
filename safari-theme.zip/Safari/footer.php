    </div> <!-- Закрытие #content -->
</div> <!-- Закрытие .wrapper -->

<footer>
	<section class="footer-widget-box py-4">
		<div class="container">
			<div class="row">
				<div class="col-md-12 col-xl-6"><a class="navbar-brand" href="<?php echo home_url(); ?>"><img src="<?php the_field('logo_footer', 'option'); ?>"><?php bloginfo('name'); ?></a></div>
				<div class="col-6 col-sm-6 col-md-6 col-xl-3">
					<div class="widget-title">Top destinations</div>
					<ul class="ft-menu">
						<li>Serengeti National Park</li>
						<li>Kilimanjaro</li>
						<li>Zanzibar</li>
						<li>Ngorongoro Conservation Area</li>
						<li>Lake Manyara</li>
						<li>Lake Natron</li>
						<li>Arusha National Park</li>
						<li>Selous Game Reserve</li>
						<li>Tarangire National Park</li>
					</ul>	
				</div>
				<div class="col-6 col-sm-6 col-md-6 col-xl-3">
					<div class="widget-title">Travel information</div>
					<ul class="ft-menu">
						<li>TAbout Tanzania Safari</li>
						<li>TContact</li>
						<li>TPrivacy policy</li>
						<li>TTerms and conditions</li>
						<li>TTanzania traveller reviews</li>
					</ul>
				</div>
			</div>
		</div>
	</section>
	<section class="text-white py-2">
		<div class="container ft-bot">
			<div class="copy"><p style="margin-bottom:0;">&copy; <?php echo date('Y'); ?> Tanzania</p> | <p style="margin-bottom:0;">Terms and conditions </p> | <p style="margin-bottom:0;">Privacy policy</p></div>
			<div class="soc"><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/social.png" /></div>
		</div>
	</section>
</footer>

<div class="overlay"></div>


<?php wp_footer(); ?>
</body>
</html>