<?php
function my_theme_enqueue_styles() {
   	wp_enqueue_style('bootstrap', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css');
	wp_enqueue_style('font-awesome', 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css');
	wp_enqueue_style( 'prepro-style', get_bloginfo('stylesheet_directory') . '/css/style.css', null );
    wp_enqueue_style('main-style', get_stylesheet_uri());
    
    wp_enqueue_script('jquery');
    wp_enqueue_script('popper', 'https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.3/dist/umd/popper.min.js', array('jquery'), '', true);
    wp_enqueue_script('bootstrap-js', 'https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js', array('jquery', 'popper'), '', true);
    wp_enqueue_script('main-js', get_template_directory_uri() . '/js/main.js', array('jquery', 'bootstrap-js'), '', true);
	//wp_enqueue_script('jquery-3-5-1', 'https://code.jquery.com/jquery-3.5.1.slim.min.js', null, true);
}
add_action('wp_enqueue_scripts', 'my_theme_enqueue_styles');

function register_my_menu() {
    register_nav_menu('main-menu', __('Header Menu'));
}
add_action('init', 'register_my_menu');

class bootstrap_5_wp_nav_menu_walker extends Walker_Nav_menu
{
    private $current_item;
    private $dropdown_menu_alignment_values = [
        'dropdown-menu-start',
        'dropdown-menu-end',
        'dropdown-menu-sm-start',
        'dropdown-menu-sm-end',
        'dropdown-menu-md-start',
        'dropdown-menu-md-end',
        'dropdown-menu-lg-start',
        'dropdown-menu-lg-end',
        'dropdown-menu-xl-start',
        'dropdown-menu-xl-end',
        'dropdown-menu-xxl-start',
        'dropdown-menu-xxl-end'
    ];

    function start_lvl(&$output, $depth = 0, $args = null)
    {
        $dropdown_menu_class[] = '';
        foreach($this->current_item->classes as $class) {
            if(in_array($class, $this->dropdown_menu_alignment_values)) {
                $dropdown_menu_class[] = $class;
            }
        }
        $indent = str_repeat("\t", $depth);
        $submenu = ($depth > 0) ? ' sub-menu' : '';
        $output .= "\n$indent<ul class=\"dropdown-menu$submenu " . esc_attr(implode(" ",$dropdown_menu_class)) . " depth_$depth\">\n";
    }

    function start_el(&$output, $item, $depth = 0, $args = null, $id = 0)
    {
        $this->current_item = $item;

        $indent = ($depth) ? str_repeat("\t", $depth) : '';

        $li_attributes = '';
        $class_names = $value = '';

        $classes = empty($item->classes) ? array() : (array) $item->classes;

        $classes[] = ($args->walker->has_children) ? 'dropdown' : '';
        $classes[] = 'nav-item';
        $classes[] = 'nav-item-' . $item->ID;
        if ($depth && $args->walker->has_children) {
            $classes[] = 'dropdown-menu dropdown-menu-end';
        }

        $class_names =  join(' ', apply_filters('nav_menu_css_class', array_filter($classes), $item, $args));
        $class_names = ' class="' . esc_attr($class_names) . '"';

        $id = apply_filters('nav_menu_item_id', 'menu-item-' . $item->ID, $item, $args);
        $id = strlen($id) ? ' id="' . esc_attr($id) . '"' : '';

        $output .= $indent . '<li ' . $id . $value . $class_names . $li_attributes . '>';

        $attributes = !empty($item->attr_title) ? ' title="' . esc_attr($item->attr_title) . '"' : '';
        $attributes .= !empty($item->target) ? ' target="' . esc_attr($item->target) . '"' : '';
        $attributes .= !empty($item->xfn) ? ' rel="' . esc_attr($item->xfn) . '"' : '';
        $attributes .= !empty($item->url) ? ' href="' . esc_attr($item->url) . '"' : '';

        $active_class = ($item->current || $item->current_item_ancestor || in_array("current_page_parent", $item->classes, true) || in_array("current-post-ancestor", $item->classes, true)) ? 'active' : '';
        $nav_link_class = ( $depth > 0 ) ? 'dropdown-item ' : 'nav-link ';
        $attributes .= ( $args->walker->has_children ) ? ' class="'. $nav_link_class . $active_class . ' dropdown-toggle" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false"' : ' class="'. $nav_link_class . $active_class . '"';

        $item_output = $args->before;
        $item_output .= '<a' . $attributes . '>';
        $item_output .= $args->link_before . apply_filters('the_title', $item->title, $item->ID) . $args->link_after;
        $item_output .= '</a>';
        $item_output .= $args->after;

        $output .= apply_filters('walker_nav_menu_start_el', $item_output, $item, $depth, $args);
    }
}

//добавьте поддержку HTML5 для навигационных меню
add_theme_support('html5', array('navigation-widgets'));



/* Вызов настроек темы */

if( function_exists('acf_add_options_page') ) {
	
	acf_add_options_page(array(
		'menu_title'	=> 'Настройки темы',
		'menu_slug' 	=> 'theme-general-settings',
	));
	
	acf_add_options_sub_page(array(
		'page_title' 	=> 'Настройки общие',
		'menu_title'	=> 'Общие',
		'parent_slug'	=> 'theme-general-settings',
	));
}


/* скрыть админ панель во фронте */
add_filter('show_admin_bar', '__return_false');

/* маска для cf7 */
function custom_cf7_phone_mask() {
    if ( function_exists( 'wpcf7_enqueue_scripts' ) ) {
        wp_enqueue_script( 'jquery-mask', 'https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js', array('jquery'), null, true );
        
        wp_add_inline_script( 'jquery-mask', '
            jQuery(document).ready(function($) {
                $(".phone-mask").mask("+7 (999) 999-99-99");
            });
        ');
    }
}
add_action( 'wp_enqueue_scripts', 'custom_cf7_phone_mask' );


/* убрать тег <p> в cf7 */
add_filter('wpcf7_autop_or_not', '__return_false');


// Добавляет SVG в список разрешенных для загрузки файлов.
function cc_mime_types($mimes) {
  $mimes['svg'] = 'image/svg+xml';
  return $mimes;
}
add_filter('upload_mimes', 'cc_mime_types');

/* шорткод калькулятора */

// Регистрация AJAX-обработчика
add_action('wp_ajax_calculate', 'calculator_ajax_handler');
add_action('wp_ajax_nopriv_calculate', 'calculator_ajax_handler');

// Функция-обработчик AJAX-запросов
function calculator_ajax_handler() {
    error_log('Calculator AJAX handler called');
    error_log('POST data: ' . print_r($_POST, true));

    $num1 = floatval($_POST['num1']);
    $num2 = floatval($_POST['num2']);
    $operation = sanitize_text_field($_POST['operation']);
    
    $result = 0;
    
    switch ($operation) {
        case '+':
            $result = $num1 + $num2;
            break;
        case '-':
            $result = $num1 - $num2;
            break;
        case '*':
            $result = $num1 * $num2;
            break;
        case '/':
            if ($num2 != 0) {
                $result = $num1 / $num2;
            } else {
                echo json_encode(array('error' => 'Деление на ноль невозможно'));
                wp_die();
            }
            break;
    }
    
    error_log('Calculator result: ' . $result);
    echo json_encode(array('result' => $result));
    wp_die();
}

// Функция для создания шорткода
function calculator_shortcode() {
    wp_enqueue_script('jquery');
    wp_enqueue_script('calculator-script', get_template_directory_uri() . '/js/calculator.js', array('jquery'), time(), true);
    wp_localize_script('calculator-script', 'calculator_ajax', array(
        'ajax_url' => admin_url('admin-ajax.php')
    ));
    
    ob_start();
    ?>
    <div id="calculator">
		<div class="calc-panel">
			<input type="number" id="num1" placeholder="Введите число">
			<select id="operation">
				<option value="+">+</option>
				<option value="-">-</option>
				<option value="*">*</option>
				<option value="/">/</option>
			</select>
			<input type="number" id="num2" placeholder="Введите число">
		</div>	
		<div id="result"></div>
    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('calculator', 'calculator_shortcode');