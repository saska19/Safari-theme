jQuery(document).ready(function($) {
    // Функция для переключения состояния сайдбара
    function toggleSidebar() {
        $('#sidebar').toggleClass('active');
        $('.overlay').toggleClass('active');
        $('body').toggleClass('sidebar-active');
    }

    // Обработчик клика для кнопки открытия сайдбара (гамбургер)
    $('#sidebarCollapse').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation(); // Предотвращаем всплытие события
        console.log('Hamburger clicked'); // Отладочное сообщение
        toggleSidebar();
    });

    // Обработчик клика для кнопки закрытия сайдбара
    $('#sidebarClose').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation(); // Предотвращаем всплытие события
        console.log('Close button clicked'); // Отладочное сообщение
        toggleSidebar();
    });

    // Закрытие сайдбара при клике на оверлей
    $('.overlay').on('click', function() {
        toggleSidebar();
    });

    // Закрытие сайдбара при клике на пункт меню
    $('#sidebar .nav-link').on('click', function(e) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            e.preventDefault();
            toggleSidebar();
            $('html, body').animate({
                scrollTop: target.offset().top - 70
            }, 1000);
        }
    });

    // Закрытие сайдбара при клике вне его области
    $(document).on('click', function(event) {
        if ($('body').hasClass('sidebar-active') && 
            !$(event.target).closest('#sidebar').length && 
            !$(event.target).is('#sidebarCollapse')) {
            toggleSidebar();
        }
    });

    // Предотвращение закрытия при клике внутри сайдбара
    $('#sidebar').on('click', function(e) {
        e.stopPropagation();
    });

    // Плавная прокрутка для всех внутренних ссылок
    $('a[href^="#"]').on('click', function(event) {
        var target = $(this.getAttribute('href'));
        if (target.length) {
            event.preventDefault();
            $('html, body').stop().animate({
                scrollTop: target.offset().top - 70
            }, 1000);
        }
    });

    // Плавное появление модального окна
    $('#contactModal').on('show.bs.modal', function () {
        $(this).find('.modal-dialog').css({
            transform: 'translate(0, -50px)'
        });
    });
    
    $('#contactModal').on('shown.bs.modal', function () {
        $(this).find('.modal-dialog').css({
            transform: 'none'
        });
    });

    // Закрытие модального окна при клике вне его области
    $(document).on('click', function(event) {
        if ($(event.target).is('#contactModal')) {
            $('#contactModal').modal('hide');
        }
    });

    // Дополнительные функции, если необходимо

    // Пример: Изменение фона навбара при прокрутке
    $(window).scroll(function() {
        if ($(this).scrollTop() > 50) {
            $('.navbar').addClass('navbar-scrolled');
        } else {
            $('.navbar').removeClass('navbar-scrolled');
        }
    });

    // Пример: Анимация появления элементов при прокрутке
    $(window).scroll(function() {
        $('.animate-on-scroll').each(function() {
            var bottom_of_object = $(this).offset().top + $(this).outerHeight();
            var bottom_of_window = $(window).scrollTop() + $(window).height();
            if (bottom_of_window > bottom_of_object) {
                $(this).addClass('animated');
            }
        });
    });
});