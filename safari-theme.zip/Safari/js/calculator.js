jQuery(document).ready(function($) {
    function calculate() {
        var num1 = $('#num1').val();
        var num2 = $('#num2').val();
        var operation = $('#operation').val();

        console.log('Sending data:', {
            action: 'calculate',
            num1: num1,
            num2: num2,
            operation: operation
        });

        $.ajax({
            url: calculator_ajax.ajax_url,
            type: 'POST',
            data: {
                action: 'calculate',
                num1: num1,
                num2: num2,
                operation: operation
            },
            success: function(response) {
                console.log('AJAX success:', response);
                var data;
                try {
                    data = JSON.parse(response);
                } catch (e) {
                    console.error('Error parsing JSON:', e);
                    $('#result').text('Ошибка при обработке ответа сервера');
                    return;
                }
                if (data.error) {
                    $('#result').text('Ошибка: ' + data.error);
                } else {
                    $('#result').text('Результат: ' + data.result);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', xhr.responseText);
                $('#result').text('Ошибка при выполнении расчета');
            }
        });
    }

    $('#num1, #num2, #operation').on('input change', calculate);
});