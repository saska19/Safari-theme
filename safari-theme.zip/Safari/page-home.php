<?php get_header(); ?>

<section id="slider">
	<div class="slider-box">
		<?php $slider = get_field('slider'); if( $slider ): ?>
		<?php foreach ($slider as $sld) : ?>
		<div class="slider-item" style="background-image:url(<?= $sld['img']; ?>);">
			<div class="container">
				<div class="slider-text-box">
					<div class="title"><?= $sld['title']; ?></div>
					<div class="subtitle"><?= $sld['subtitle']; ?></div>
					<a href="<?= $sld['link']; ?>" class="btn butt">Book a tour</a>

					<ul class="advant">
						<?php $advantages = $sld['advantages']; if( $advantages ): ?>
							<?php foreach ($advantages as $advnt) : ?>
						<li><img src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/tick-circle.png" /><?= $advnt['item']; ?></li>
							<?php endforeach; ?>
						<?php endif; ?>
					</ul>

				</div>
			</div>	
		</div>
		<?php endforeach; ?>
	<?php endif; ?>
	</div>	
</section>


<main>

    <section id="about" class="py-5">
        <div class="container">
            <div class="row">
				<?php $about = get_field('about'); if( $about ): ?>
				<div class="col-12 col-sm-12 col-md-12 col-lg-6 img-box">
					<div class="img-wrap"><img src="<?php echo $about['img']; ?>" /></div>
				</div>
				<div class="col-12 col-sm-12 col-md-12 col-lg-6 text-box">
					<div class="text-wrap">
						<div class="subtitle"><?php echo $about['subtitle']; ?></div>
						<h2 class="title"><?php echo $about['title']; ?></h2>
						<div class="row desc">
							<?php $characteristics = $about['characteristics']; if( $characteristics ): ?>
							<?php foreach ($characteristics as $charact) : ?>
							<div class="col-6 col-sm-6 col-md-6 col-lg-6 item">
								<div class="num"><?= $charact['num']; ?></div>
								<div class="text"><?= $charact['text']; ?></div>
							</div>
							<?php endforeach; ?>
							<?php endif; ?>
						</div>
						<div class="calc-box">
							<div class="title">Vacation calculator</div>
							<?php echo do_shortcode('[calculator]'); ?>
						</div>
					</div>	
				</div>
				<?php endif; ?>
			</div>
        </div>
    </section>


</main>

<?php get_footer(); ?>