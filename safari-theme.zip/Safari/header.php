<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
    <meta charset="<?php bloginfo('charset'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>
<?php wp_body_open(); ?>

<header>
    <nav class="navbar navbar-expand-lg navbar-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="<?php echo home_url(); ?>"><img src="<?php the_field('logo_head', 'option'); ?>"><?php bloginfo('name'); ?></a>
			<div class="row navbar-menu">
				<?php
					wp_nav_menu(array(
						'theme_location' => 'main-menu',
						'container' => false,
						'menu_class' => 'nav flex-column',
						'fallback_cb' => '__return_false',
						'items_wrap' => '<ul id="%1$s" class="navbar-nav me-auto mb-2 mb-md-0 nav">%3$s</ul>',
						'depth' => 2,
						'walker' => new bootstrap_5_wp_nav_menu_walker()
					));
				?>
			</div>
			<div class="btn-box"><a href="#" class="btn butt">Book a tour</a></div>
            <button class="navbar-toggler" type="button" id="sidebarCollapse">
                <span class="navbar-toggler-icon"></span>
            </button>
        </div>
    </nav>
</header>

<div class="wrapper">
    <nav id="sidebar">
        <button type="button" id="sidebarClose" class="close" aria-label="Close">
            <span aria-hidden="true">&times;</span>
        </button>
        <?php
        wp_nav_menu(array(
            'theme_location' => 'main-menu',
            'container' => false,
            'menu_class' => 'nav flex-column',
            'fallback_cb' => '__return_false',
            'items_wrap' => '<ul id="%1$s" class="%2$s">%3$s</ul>',
            'depth' => 2,
            'walker' => new bootstrap_5_wp_nav_menu_walker()
        ));
        ?>
		<div class="container side-btn-box">
			<div class="btn-box"><a href="#" class="btn butt">Book a tour</a></div>
		</div>	
    </nav>
	
    
<div id="content">	