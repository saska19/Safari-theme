<?php get_header(); ?>
<div style="margin-top: 160px;"></div>
<main>
    <section>
        <div class="container">
			<h1><?the_title();?></h1>
			<?the_content();?>
        </div>
    </section>
</main>

<?php get_footer(); ?>